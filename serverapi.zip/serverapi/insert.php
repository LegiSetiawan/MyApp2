<?php
include_once('coneksi.php');
if (!empty($_POST['nama']) && !empty($_POST['harga']) && !empty($_POST['satuan']) && !empty($_POST['total'])) {
$nama = $_POST['nama'];
$harga = $_POST['harga'];
$satuan = $_POST['satuan'];
$total = $_POST['total'];
$query = "INSERT INTO sayur(nama,harga,satuan,total) VALUES
('$nama','$harga','$satuan',$total)";
$insert = mysqli_query($connect, $query);
if($insert) {
set_response(true, "Success insert data");
}
else {
set_response(false, "Failed insert data");
}
} else {
set_response(false, "Nama, harga,satuan dan total harus diisi");
}
function set_response($isSuccess, $message){
$result = array(
'isSuccess' => $isSuccess,
'message' => $message
);
echo json_encode($result);
}
