<?php
$hostname = "localhost";
$username = "root";
$password = "x0D7mLEnEITL7eQE";
$database = "udaapp";
$connect = mysqli_connect($hostname, $username, $password, $database);
if (mysqli_connect_errno()) {
echo "Failed connect to MySql: " . mysql_connect_error(); die();
}