<?php
include_once('coneksi.php');
if (!empty($_POST['id']) && !empty($_POST['nama']) && !empty($_POST['harga']) && !empty($_POST['satuan']) && !empty($_POST['total'])){
$id = $_POST['id'];
$nama = $_POST['nama'];
$harga = $_POST['harga'];
$satuan = $_POST['satuan'];
$total = $_POST['total'];
$query = "UPDATE sayur set nama = '$nama', harga = '$harga', satuan ='$satuan', total = '$total' WHERE id = '$id'";
$update = mysqli_query($connect, $query);
if($update) {
    set_response(true, "Success update data");
}
else {
set_response(false, "Failed update data");
}
} else {
set_response(false, "id, Nama, harga,satuan dan total harus diisi");
}
function set_response($isSuccess, $message){
$result = array(
'isSuccess' => $isSuccess,
'message' => $message
);
echo json_encode($result);
}
